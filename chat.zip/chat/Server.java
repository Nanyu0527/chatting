public class Server {
    public static void main(String[] args) {
    	new Server_GUI();
    }
}
