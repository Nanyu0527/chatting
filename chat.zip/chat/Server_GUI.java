import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.MatteBorder;


@SuppressWarnings("serial")
public class Server_GUI extends JFrame {
	
	private JPanel contentPanel = new JPanel();
	
	private JTextArea monitorTa;
	
	private JScrollPane monitorSp;
	
	public Server_GUI() {
		this.init();
	}

	@SuppressWarnings("deprecation")
	private void init() {
		String port;
		int portnum = 0;
		boolean port_valid = false;
		do {
			port_valid = true;
			port = JOptionPane.showInputDialog(this,"input the port name","server",JOptionPane.PLAIN_MESSAGE);
	        try {
	        	portnum = Integer.parseInt(port);
	        }
	        catch(Exception e) {
	        	JOptionPane.showMessageDialog(null, "port name need 1-65535 integer!", "Error",JOptionPane.ERROR_MESSAGE);
	        	port_valid = false;
				System.exit(0);
	        }
		} while(!port_valid);

		this.setTitle("Server");  					
		this.setSize(610, 570);  					
        setDefaultCloseOperation(EXIT_ON_CLOSE);	
        setLocationRelativeTo(null);  				
        setVisible(true);  							
        Toolkit kit =Toolkit.getDefaultToolkit();
		monitorTa = new JTextArea("", 500, 80);
        Color color = new Color(255,255,245);
        monitorTa.setBackground(color);
        monitorTa.setEditable(false);
        
        monitorSp = new JScrollPane(monitorTa);           
        setLayout(null);
		add(monitorSp);
	
		monitorSp.setBounds(0, 0, 597, 535);

		contentPanel.setOpaque(false);
		Server_Socket sersoc = new Server_Socket(portnum, this);
		sersoc.listen();
	}

    public void MonitorTaDisplay(String msg) {
    	monitorTa.append(msg);
    	monitorTa.setCaretPosition(monitorTa.getText().length() - 1);
    }
	
}