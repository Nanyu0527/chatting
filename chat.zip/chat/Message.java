import java.io.Serializable;

public class Message implements Serializable{
	protected static final long serialVersionUID = 3200105705L;	
    static final int MESSAGE = 0, USERLIST = 1;
    private int type;
    private String content;

    Message(int type, String content) {
        this.type = type;
        this.content = content;
    }
    int getType() {
        return type;
    }
    String getContent() {
        return content;
    }
}