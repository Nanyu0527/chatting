public class client {
	
	public static Clientlogin_GUI client;
	
    public static void main(String[] args) {
    	new Clientlogin_GUI();
    }
}