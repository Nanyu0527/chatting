import java.io.IOException;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

import javax.swing.JOptionPane;

public class Client_Socket {
	private Socket cliSocket;				
	private ObjectInputStream socketIn;		
	private ObjectOutputStream socketOut;	
	private String serverIP;				
	private int port;						
	private String username;				
	private chat_GUI chatRoom;		
	
	public Client_Socket(String serverIP, int port, String username, chat_GUI chatRoom) {
		this.serverIP = serverIP;
		this.port = port;
		this.username = username;
		this.chatRoom = chatRoom;
	}
	
	public boolean connectServer() {
		try {
			cliSocket = new Socket(serverIP,port);
		}catch (Exception e) {
			JOptionPane.showMessageDialog(null, "connect error", "Error",JOptionPane.ERROR_MESSAGE);
			return false;
		}
		JOptionPane.showMessageDialog(null, "connect succeed");
		String errorMsg;
		
		try {
			socketIn = new ObjectInputStream(cliSocket.getInputStream());
			socketOut = new ObjectOutputStream(cliSocket.getOutputStream());
		}catch (Exception e) {
			errorMsg = "创建套接字的I/O流时出错! " + e;
			JOptionPane.showMessageDialog(null, errorMsg, "Error",JOptionPane.ERROR_MESSAGE);
			return false;
		}
		
		try {
			socketOut.writeObject(username);
		}catch (IOException e) {
			errorMsg = "error when send message to server " + e;
			JOptionPane.showMessageDialog(null, errorMsg, "Error",JOptionPane.ERROR_MESSAGE);
			return false;
		}	

		new InteractWithServer().start();
		return true;
	}
	
	class InteractWithServer extends Thread{
		@Override
		public void run() {
			while(true) {
				try {
					Message servermsg = (Message) socketIn.readObject();
					String content = servermsg.getContent();
	                switch(servermsg.getType()) {
                    case Message.MESSAGE:
                    	chatRoom.ChattingTaDisplay(content);
                        break;
                    case Message.USERLIST:
                    	chatRoom.UserlistTaClear();
                    	chatRoom.UserlistTaDisplay(content);
                        break;
                }
					
				} catch (Exception e) {
					JOptionPane.showMessageDialog(null, "disconnected with server");
					chatRoom.setVisible(false);
					break;
				}
			}
		}
	}
	public void sendMessage(Message msg) {
		try {
		socketOut.writeObject(msg);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "error when sending message", "Error",JOptionPane.ERROR_MESSAGE);
		}
	}
	
}