import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.MatteBorder;


@SuppressWarnings("serial")
public class Clientlogin_GUI extends JFrame {
	
	private JPanel contentPanel = new JPanel();
	
	private JLabel bgLabel;
	private JLabel serverLabel = new JLabel("server IP addr:");
	private JLabel portLabel = new JLabel("port:");
	private JLabel userLabel = new JLabel("user name:");
	private JLabel titleLabel = new JLabel("Welcome");
	
	private JButton loginBtn = new JButton("login in");
	private JTextField serverTf = new JTextField("127.0.0.1");
	private JTextField portTf = new JTextField("5705");
	private JTextField userTf = new JTextField();
	
	public static chat_GUI chatRoom = new chat_GUI();
	public static Client_Socket Client;
	private int flag = 0;
	public Clientlogin_GUI() {
		this.init();
		this.addListener();
	}

	@SuppressWarnings("deprecation")
	private void init() {
		
		this.setTitle("client login");  			
		this.setSize(500, 315);  					
        setDefaultCloseOperation(EXIT_ON_CLOSE);	
        setLocationRelativeTo(null);  				
        setVisible(true);  							
        Toolkit kit =Toolkit.getDefaultToolkit();
		bgLabel = new JLabel();
		bgLabel.setBounds(0, 0, 500, 280);
		
		this.getLayeredPane().add(bgLabel, new Integer(Integer.MIN_VALUE));
		((JPanel) this.getContentPane()).setOpaque(false);

		contentPanel.setLayout(null);
		add(serverTf);
		add(portTf);
		add(userTf);
		add(loginBtn);
		add(serverLabel);
		add(portLabel);
		add(titleLabel);
		add(userLabel);

		/* Position setting */	
		serverTf.setBounds(140, 110, 240, 20);
		portTf.setBounds(140, 140, 240, 20);
		userTf.setBounds(140, 170, 240, 20);
		
		Font f1 = new Font("宋体", Font.BOLD + Font.ITALIC, 12);
		serverLabel.setBounds(52, 107, 90, 25);
		serverLabel.setFont(f1);
		serverLabel.setForeground(Color.RED);	
		
		portLabel.setBounds(105, 137, 90, 25);
		portLabel.setFont(f1);
		portLabel.setForeground(Color.RED);

		userLabel.setBounds(70, 167, 90, 25);
		userLabel.setFont(f1);
		userLabel.setForeground(Color.RED);

		titleLabel.setBounds(165, 50, 200, 50);
		Font f2 = new Font("楷书", Font.BOLD, 38);
		titleLabel.setFont(f2);
		titleLabel.setForeground(Color.BLACK);
		
		loginBtn.setBounds(200, 225, 100, 30);
		contentPanel.setOpaque(false);
		getContentPane().add(contentPanel);
	}


	private void addListener() {
		loginBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				flag=1;
				forloginBtn(serverTf.getText().trim(), portTf.getText().trim(), userTf.getText().trim());
			}

		});
	}

	public void forloginBtn(String serverIP, String port, String username) {
		int portnum;
        if(serverIP.length() == 0){
        	JOptionPane.showMessageDialog(null, "server IP can't be empty!", "Error",JOptionPane.ERROR_MESSAGE);
            return;
        }
        if(port.length() == 0){
        	JOptionPane.showMessageDialog(null, "端口号不能为空！", "Error",JOptionPane.ERROR_MESSAGE);
            return;
        }
        if(username.length() == 0){
        	JOptionPane.showMessageDialog(null, "用户名不能为空！", "Error",JOptionPane.ERROR_MESSAGE);
            return;
        }
        try {
        	portnum = Integer.parseInt(port);
        }
        catch(Exception e) {
        	JOptionPane.showMessageDialog(null, "端口号需要为1-65535的整数！", "Error",JOptionPane.ERROR_MESSAGE);
            return;
        }
        
		Client = new Client_Socket(serverIP, portnum, username, chatRoom);
		if(!Client.connectServer())
			return;
		setVisible(false);  	
	    chatRoom.setVisible(true);				
	}
}

